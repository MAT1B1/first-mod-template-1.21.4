package com.firstmod;

import net.fabricmc.api.ClientModInitializer;

public class FirstModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}